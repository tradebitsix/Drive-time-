# DriverEdOS (Full Stack)

Monorepo:
- backend/ FastAPI async + Postgres + Alembic + JWT roles
- frontend/ React + Vite + Tailwind v4 + shadcn-style UI + TanStack Query/Table
