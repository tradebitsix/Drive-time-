# DriverEdOS Backend

FastAPI (async) + PostgreSQL + Alembic + JWT roles.
